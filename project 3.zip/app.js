var main = function() {
    var state;
  var volume;
  //The PLAY button
$('#play').click(function(){
    $('#message').text("Playing track");
    $('#player').trigger("play");
});

//The PAUSE button
$('#pause').click(function(){
    $('#message').text("Track paused");
    $('#player').trigger("pause");
});

 //The MUTE button
    $('#mute').click(function(){
        $('#message').text("Track muted");
        $('#player').prop('muted', true);
    });

 //The UNMUTE button
    $('#unmute').click(function(){
        $('#message').text("Track unmuted");
        $('#player').prop('muted', false);
    });

//The STOP button
    $('#stop').click(function(){
        $('#message').text("Track stopped");
        $('#player').trigger("pause"); // Pause the music
        $('#player').prop('currentTime', 0); // Reset currentTime to 0
    });

//The VOLUME UP button
    $('#volUp').click(function(){
        var currentVolume = $('#player').prop('volume');
        if (currentVolume < 1) {
            var newVolume = Math.min(1, currentVolume + 0.1);
            $('#player').prop('volume', newVolume);
            $('#message').text("Volume increased");
        } else {
            console.log("Volume is already at maximum");
        }
    });

//The VOLUME DOWN button
    $('#volDown').click(function(){
        var currentVolume = $('#player').prop('volume');
        if (currentVolume > 0) {
            var newVolume = Math.max(0, currentVolume - 0.1);
            $('#player').prop('volume', newVolume);
            $('#message').text("Volume decreased");
        } else {
            console.log("Volume is already at minimum");
        }
    });
}

$(document).ready(main);