t = require('/home/codio/workspace/.guides/tests/test-create.js')

t.test(function(data){
  console.log(data)  
});
